# dsh-meetai — DSH 会议助手插件

会议日程与 AI 议程、模板纪要生成与签署归档、可溯源会议问答。以**主内容区应用**形态运行（非侧栏），
通过工作台 / 能力包入口打开，或在任意会话中监听 `cappacks:open-meeting` 事件直达对应页签。

v0.2 布局：面板自带**左侧导航栏**（品牌区 / 会议日程 / 新建会议 / 会议纪要 / 会议问答（可展开二级：「新建对话」按钮 +「历史对话」标签及其下全部历史会话）/ 统计卡 / 返回会话），
紧挨 DSH 左侧导航展示；配色全部使用 DSH 主题令牌（`--dsw-specific-sidebar-fill` 等），随「通用设置 → 外观」明暗自动切换；
DSH 左侧导航本身保持不变，仅在本面板打开时若其侧栏处于展开态则自动收起一次（可随时手动展开）。

## 功能

- **会议日程**：列表（置顶优先 + 开始时间降序）/ 周日历 / 月日历（悬停浮窗）；
  仅看置顶、状态筛选（按 now 推导：待开始 / 进行中 / 已结束）、关键词搜索（标题/地点/参会人/标签）；
  星标置顶（PATCH）；状态徽标 + 纪要状态徽标（待生成 / AI纪要待签署 / 已归档）；详情弹窗；直达纪要 / 问答。
- **新建会议**：全字段表单（形式联动地点 label、参会人/标签逗号分隔、置顶复选、议程行增删）；
  **AI 一键议程生成**（宿主 LLM + JSON 容错解析回填）；材料挂载（≤10MB，TXT/MD 提取文本入库供检索）。
- **会议纪要**：三种来源——**① 实时录音**（旧浏览器 MediaRecorder + WebSpeech，结束后自动生成，录音可回放/下载；不等同本次阿昆录音中字幕）；**② 上传录音**（≤500MB，服务端流式写盘，进度100%仅表示传输完成，服务端确认后按钮可点；点击后由本地阿昆 Paraformer 离线全文件转写并保存，随后调用现有文字模型生成纪要；仍支持手工修订/导入转写）；**③ 粘贴文本**（原行为）。
  绑定会议（可选）→ 阿昆三类纪要模板（周例会 / 项目沟通会 / 专题推进会）
  → AI 生成 Markdown 纪要（附结构化待办）→ 在线编辑（保存 version+1）/ 导入修正版覆盖（version+1、source=import）
  → **正式签署归档**（服务端 SHA-256 指纹 + 归档时间，回写会议 minutes_status）；待办清单勾选同步。
- **会议问答**（v0.2.6）：单一对话框，后台经 DSH `agents` 会话能力创建/复用编程式会话并发起 SSE 流式回答，
  **在本页直接显示**（不再跳转 DSH 会话视图）；左侧导航「会议问答」**默认收起、点击父项展开**，下挂二级目录
  **「✚ 新建对话」按钮** 与 **「🕘 历史对话」标签**——历史对话是分组标签而非按钮，
  全部历史会话平铺其下（点击载入 / 悬停删除，计数徽标显示会话数）；
  对话框顶栏一行排布：左上角**全量会议资产**检索范围（全量 / 仅文档 / 单场会议）+ **「➕ 新建会议」提示标签**
  （点击插入引导模板，补全发送后由模型调用 **meeting_create** Host 工具把会议写入会议日程），右侧为**模型选择**
  （`GET /models`，与 DSH「设置-模型」同源，缺省跟随系统默认）；
  对话框高度默认加倍（1040px）且支持**底部把手拖拽调整**（520~2200px，localStorage 记忆）；
  输入栏 sticky 吸底：对话框高于视口时输入栏与把手仍常驻可视区，无需滚动即可输入；
  支持 **📎 附件**（按钮多选 + 对话区拖拽上传，PDF/DOCX/XLSX/TXT/MD ≤30MB，
  服务端落盘 `uploads/` 后随问题交由会话读取）；消息随 turn/end 自动持久化进 qa-sessions 存储。旧 `/ask`（BM25 内置速答）接口保留但 UI 不再使用。

## 安装

1. 把本目录放入 profile 的 `node_modules`（`link:` 或 tgz 均可）；
2. 在 profile `package.json` 的 `dsh.profile.bundles` 追加 bundle id **`meetai`**（即 cordis.patch.yml 的 insert id）；
3. 宿主自动热重组；浏览器半改动即时热替换，宿主半（index.js）改动需重启实例。

## HTTP API（前缀 `/api/meeting-assistant`）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/templates` | 阿昆三类纪要模板 `{templates:[{id,name,subtitle,scene}]}`（工作台探活依赖） |
| POST | `/recordings/:id/transcribe` | 本地阿昆离线正式转写；录音哈希检查、单任务并发、非空结果保存，失败明确返回，不冒充纪要 |
| GET/POST | `/meetings` | 会议列表（含按 now 推导的 status）/ 创建 |
| GET/PATCH/DELETE | `/meetings/:id` | 详情 / 局部更新（置顶等）/ 删除 |
| POST | `/agenda` | AI 议程生成（返回 `{agenda:[{time_range,topic,speaker,objective}]}`） |
| POST | `/generate-text` | AI 纪要生成（`{meeting_id, transcript, template_type}` → `{minutes}`） |
| GET | `/minutes` / `/minutes/meeting/:meetingId` / `/minutes/:minutesId` | 纪要列表 / 按会议取最新 / 按 id |
| PUT | `/minutes/:minutesId` | 保存正文（version+1）/ 勾选待办（不动版本） |
| POST | `/minutes/:minutesId/archive` | 签署归档（SHA-256 指纹 + 回写日程） |
| GET/POST/DELETE | `/docs`(`/docs/:fileId`) | 挂载材料（TXT/MD 含 text 入库检索） |
| POST | `/ask` | 问答（旧内置速答：`{question, scope, history}` → `{answer, sources:[{id,label,meeting_title,timestamp,text}]}`；v0.2.4 起 UI 默认走 `/qa`） |
| POST | `/qa` | 统一问答（SSE 流式；`{question, sessionId?, provider?, model?, scope?, files?}`；帧：status/delta/thinking/tool/turn_end/error；turn_end 落盘 qa-sessions） |
| POST | `/upload?name=` | 问答附件上传落盘（原始字节；≤30MB；.pdf/.docx/.xlsx/.txt/.md → `{ok,file:{id,name,path,size}}`） |
| GET | `/models` | 可选模型目录（与 DSH「设置-模型」同源；`{ok,default,groups,failures}`） |
| GET/POST/PUT/DELETE | `/qa-sessions`(`/​:id`) | 问答会话持久化（v0.2.4 起由 /qa turn_end 自动写入） |

**Host 工具**：`meeting_create`（对话式新建会议：title/start_time/end_time 必填，location/type/participants/tags/agenda/is_pinned 可选；写入 meetings.json 并回 `{ok, meeting}` 供模型向用户确认）。

## 数据

`$DSH_HOME/meeting-assistant/`：`meetings.json`、`minutes/index.json`、`minutes/<date>/<id>.md`（+ 同名 .json 存转写）、
`docs.json`、`qa-sessions.json`。与 `@local/meetai-sidebar-v2` 的 meetings.json / minutes 布局兼容，旧数据可延续。

## 自检

```bash
node --check index.js && node --check client.js
node scripts/smoke.mjs   # DSH_HOME 隔离到 .smoke-tmp，覆盖 templates/meetings/agenda/minutes/archive/ask/docs/qa
```

## 范围说明

P2 项（真实声纹、向量库、OCR、外部系统同步、加密等）未实现且无 UI 入口；上传音频需本机阿昆 Python/四组离线权重和可用解码器，`DSH_AKUN_RELEASE`、`DSH_AKUN_PYTHON`可覆盖受控路径。仅源代码与假 runner 回归不代表已发布：需真实音频转写、文字模型生成、现有GUI刷新与回滚验证。
